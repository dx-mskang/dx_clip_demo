import numpy as np


class NumpyDataTypeMapper:
    INT8 = np.int8
    UINT8 = np.uint8
    FLOAT = np.float32
